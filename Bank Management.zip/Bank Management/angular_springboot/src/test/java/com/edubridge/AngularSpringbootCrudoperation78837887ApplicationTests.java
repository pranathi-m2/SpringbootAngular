package com.edubridge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AngularSpringbootCrudoperation78837887ApplicationTests {

	@Test
	void contextLoads() {
	}

}
