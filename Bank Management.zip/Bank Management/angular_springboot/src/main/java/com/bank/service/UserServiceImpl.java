package com.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.bank.entity.User;
import com.bank.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
	private UserRepository userRepository;
	@Override
	public void register(User user) {
		userRepository.save(user);
		
	}
	@Override
	public List<User> findAllUsers() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}
	@Override
	public User findUserById(Integer id) {
		// TODO Auto-generated method stub
		return userRepository.findById(id).get();
	}
	@Override
	public List<User> findByEmail(String email) {
		// TODO Auto-generated method stub
		return userRepository.findByEmail(email);
	}
	@Override
	public List<User> cancelRegisteration(Integer id) {
		// TODO Auto-generated method stub
		userRepository.deleteById(id);;
		return userRepository.findAll();
	}
	@Override
	public User updateUserById(int id, User user) {
		User dbUser=userRepository.findById(id).get();
		dbUser.setBank(user.getBank());
		dbUser.setEmail(user.getEmail());
		dbUser.setBalance(user.getBalance());
		dbUser.setName(user.getName());
		
		return userRepository.save(dbUser);
	}
	

}
