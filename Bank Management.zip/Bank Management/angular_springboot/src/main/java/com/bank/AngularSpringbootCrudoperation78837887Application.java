package com.bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AngularSpringbootCrudoperation78837887Application {

	public static void main(String[] args) {
		SpringApplication.run(AngularSpringbootCrudoperation78837887Application.class, args);
	}

}
